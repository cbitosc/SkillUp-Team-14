from flask import Flask,jsonify
from flask_restful import Api
from flask_jwt_extended import JWTManager
from resources.emp import Emp,EmpLogin
from resources.hod import Hod,HodLogin
from resources.dept import Dept
from resources.leaveapproval import Leaveapproval
from resources.empleave import Empleave
from resources.empattendence import Empattendence
from resources.deptleave import Deptleave
from resources.leaveidinfo import LeaveIdInfo
from resources.leavesleft import LeavesLeft
from resources.updatebyhod import UpdateByHod
from resources.leaveapprovalupdate import Leaveapprovalupdate
from resources.updatepassword import UpdatePassword

app=Flask(__name__)
app.config['PROPAGATE_EXCEPTIONS']=True
app.config['JWT_SECRET_KEY']='coscskillup'
api=Api(app)
jwt=JWTManager(app)

@jwt.unauthorized_loader
def missing_token_callback(error):
    return jsonify({
        'error': 'authorization_required',
        "description": "Request does not contain an access token."
    }), 401

@jwt.invalid_token_loader
def invalid_token_callback(error):
    return jsonify({
        'error': 'invalid_token',
        'message': 'Signature verification failed.'
    }), 401

api.add_resource(Emp,'/emp_register')
api.add_resource(EmpLogin,'/emp_login')
api.add_resource(Dept,'/dept')
api.add_resource(Deptleave,'/deptleave')
api.add_resource(Leaveapprovalupdate,'/leaveapprovalupdate')
api.add_resource(UpdateByHod,'/updatebyhod')
api.add_resource(LeavesLeft,'/leavesleft')
api.add_resource(LeaveIdInfo,'/leaveidinfo')
api.add_resource(Empleave,'/empleave')
api.add_resource(Empattendence,'/empattendence')
api.add_resource(Leaveapproval,'/leaveapproval')
api.add_resource(Hod,'/hod_register')
api.add_resource(HodLogin,'/hod_login')
api.add_resource(UpdatePassword,'/updatepassword')

if __name__=='__main__':
    app.run()
