from flask_restful import Resource,reqparse
from werkzeug.security import safe_str_cmp
from flask_jwt_extended import create_access_token,jwt_required
from db import query
from datetime import datetime

class Emp(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.EMP_REGISTER WHERE EMPID={data['EMPID']}""")
        except:
            return {"message":"There was an error connecting to emp_register table."},500

    
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        parser.add_argument('EMPNAME',type=str,required=True,help="empname cannot be left blank!")
        parser.add_argument('DEPTNO',type=int,required=True,help="deptno cannot be left blank!")
        parser.add_argument('DESG',type=str,required=True,help="desg cannot be left blank!")
        parser.add_argument('EMAIL',type=str,required=True,help="email cannot be left blank!")
        parser.add_argument('CONTACT',type=str,required=True,help="contact cannot be left blank!")
        parser.add_argument('ADDRESS',type=str,required=True,help="Address cannot be left blank!")
        parser.add_argument('PASS',type=str,required=True,help="password cannot be left blank!")
        parser.add_argument('NOLEAVES',type=int,required=True,help="NO of leaves cannot be left blank!")
        data=parser.parse_args()
        try:
            x=query(f"""SELECT * FROM LEAVE_APP1.EMP_REGISTER WHERE EMPID={data['EMPID']}""",return_json=False)
            if len(x)>0: return {"message":"An emp with that empid already exists."},400
        except:
            return {"message":"There was an error inserting into emp_register table."},500
        try:
            query(f"""INSERT INTO LEAVE_APP1.EMP_REGISTER VALUES({data['EMPID']},
                                                        '{data['EMPNAME']}',
                                                        {data['DEPTNO']},
                                                        '{data['DESG']}',
                                                        '{data['EMAIL']}',
                                                        '{data['CONTACT']}',
                                                        '{data['ADDRESS']}',
                                                        '{data['PASS']}',
                                                        {data['NOLEAVES']})""")
        except:
            return {"message":"There was an error inserting into emp_register table."},500
        return {"message":"Successfully Inserted."},201
  

class User():
    def __init__(self,EMPID,EMPNAME,PASSWORD):
        self.EMPID=EMPID
        self.EMPNAME=EMPNAME
        self.PASSWORD=PASSWORD

    @classmethod
    def getUserByEname(cls,EMPNAME):
        result=query(f"""SELECT EMPID,EMPNAME,PASS FROM EMP_REGISTER WHERE EMPNAME='{EMPNAME}'""",return_json=False)
        if len(result)>0: return User(result[0]['EMPID'],result[0]['EMPNAME'],result[0]['PASS'])
        return None

    @classmethod
    def getUserByempno(cls,EMPID):
        result=query(f"""SELECT EMPID,EMPNAME,PASS FROM EMP_REGISTER WHERE EMPID='{EMPID}'""",return_json=False)
        if len(result)>0: return User(result[0]['EMPID'],result[0]['EMPNAME'],result[0]['PASS'])
        return None
now = datetime.now()
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")

class EmpLogin(Resource):
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=str,required=True,help="empid cannot be left blank!")
        parser.add_argument('PASS',type=str,required=True,help="password cannot be left blank!")
        data=parser.parse_args()
        user=User.getUserByempno(data['EMPID'])
        if user and safe_str_cmp(user.PASSWORD,data['PASS']):
            access_token=create_access_token(identity=user.EMPID,expires_delta=False)
            
        return {"message":"Invalid Credentials!"}, 401

