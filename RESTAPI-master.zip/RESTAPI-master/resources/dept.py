from flask_restful import Resource,reqparse
from db import query
from flask_jwt_extended import jwt_required


class Dept(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('DEPTNO',type=int,required=True,help="deptno cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.DEPT WHERE DEPTNO={data['DEPTNO']}""")
        except:
            return {"message":"There was an error connecting to dept table."},500

    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('DEPTNO',type=int,required=True,help="deptno cannot be left blank!")
        parser.add_argument('DEPTNAME',type=str,required=True,help="deptname cannot be left blank!")
        parser.add_argument('HOD',type=str,required=True,help="hod cannot be left blank!")
        data=parser.parse_args()
        try:
            x=query(f"""SELECT * FROM LEAVE_APP1.DEPT WHERE DEPTNO={data['DEPTNO']}""",return_json=False)
            if len(x)>0: return {"message":"that deptno already exists."},400
        except:
            return {"message":"There was an error inserting into dept table."},500
        try:
            query(f"""INSERT INTO LEAVE_APP1.DEPT VALUES({data['DEPTNO']},
                                                        '{data['DEPTNAME']}',
                                                        '{data['HOD']}')""")
        except:
            return {"message":"There was an error inserting into DEPT table."},500
        return {"message":"Successfully Inserted."},201