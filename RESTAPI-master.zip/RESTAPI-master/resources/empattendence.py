from flask_restful import Resource,reqparse
from flask_jwt_extended import jwt_required
from db import query


class Empattendence(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT EMPID,LEAVE_ID,STDATE,ENDDATE FROM LEAVE_APP1.EMP_LEAVE_APPLICATION WHERE 
                                EMPID={data['EMPID']} AND LEAVE_ID=ANY(SELECT LEAVE_ID FROM LEAVE_APP1.LEAVES_APPROVAL
                                WHERE LEAVE_STAT=1)""")
        except:
            return {"message":"There was an error connecting to emp_leave_application table."},500


    
  