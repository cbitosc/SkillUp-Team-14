from flask_restful import Resource,reqparse
from werkzeug.security import safe_str_cmp
from flask_jwt_extended import create_access_token,jwt_required
from db import query


class UpdatePassword(Resource):
    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('HODNAME',type=str,required=True,help="hod name cannot be left blank!")
        parser.add_argument('PASS',type=str,required=True,help="password cannot be left blank!")
        data=parser.parse_args()
        try:
            query(f"""UPDATE LEAVE_APP1.HOD_REGISTER SET PASS='{data['PASS']}' WHERE HODNAME='{data['HODNAME']}'""")
        except:
            return {"message":"There was an error connecting to HOD_register table."},500
        return {"message":"Successfully Inserted."},201