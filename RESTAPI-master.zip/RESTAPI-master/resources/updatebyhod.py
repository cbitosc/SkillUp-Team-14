from flask_restful import Resource,reqparse
from werkzeug.security import safe_str_cmp
from flask_jwt_extended import create_access_token,jwt_required
from db import query


class UpdateByHod(Resource):
    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        parser.add_argument('NOLEAVES',type=int,required=True,help="no of leaves cannot be left blank!")
        data=parser.parse_args()
        try:
            query(f"""UPDATE LEAVE_APP1.EMP_REGISTER SET NOLEAVES={data['NOLEAVES']} WHERE EMPID={data['EMPID']}""")
        except:
            return {"message":"There was an error connecting to emp_register table."},500
        return {"message":"Successfully Inserted."},201