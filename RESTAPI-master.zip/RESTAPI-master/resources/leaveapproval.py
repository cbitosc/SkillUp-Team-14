from flask_restful import Resource,reqparse
from db import query
from flask_jwt_extended import jwt_required


class Leaveapproval(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('LEAVE_ID',type=int,required=True,help="leave id cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.LEAVES_APPROVAL WHERE LEAVE_ID={data['LEAVE_ID']}""")
        except:
            return {"message":"There was an error connecting to LEAVES_APPROVAL table."},500

    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('LEAVE_ID',type=int,required=True,help="leave id cannot be left blank!")
        parser.add_argument('LEAVE_STAT',type=int,required=True,help="leave status cannot be left blank!")
        parser.add_argument('LEAVE_MSG',type=str,required=True,help="leave message cannot be left blank!")
        data=parser.parse_args()
        try:
            x=query(f"""SELECT * FROM LEAVE_APP1.LEAVES_APPROVAL WHERE LEAVE_ID={data['LEAVE_ID']}""",return_json=False)
            if len(x)>0: return {"message":"that leave id already exists."},400
        except:
            return {"message":"There was an error inserting into LEAVES_APPROVAL table."},500
        try:
            query(f"""INSERT INTO LEAVE_APP1.LEAVES_APPROVAL VALUES({data['LEAVE_ID']},
                                                        {data['LEAVE_STAT']},
                                                        '{data['LEAVE_MSG']}')""")
        except:
            return {"message":"There was an error inserting into LEAVES_APPROVAL table."},500
        return {"message":"Successfully Inserted."},201