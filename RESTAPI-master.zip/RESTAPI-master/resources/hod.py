from flask_restful import Resource,reqparse
from werkzeug.security import safe_str_cmp
from flask_jwt_extended import create_access_token,jwt_required
from db import query
from datetime import datetime

class Hod(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('HODNAME',type=str,required=True,help="hod name cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.HOD_REGISTER WHERE HODNAME='{data['HODNAME']}' """)
        except:
            return {"message":"There was an error connecting to hod_register table."},500

    
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('HODID',type=int,required=True,help="hodid cannot be left blank!")
        parser.add_argument('HODNAME',type=str,required=True,help="hodname cannot be left blank!")
        parser.add_argument('DEPTNO',type=int,required=True,help="deptno cannot be left blank!")
        parser.add_argument('DESG',type=str,required=True,help="desg cannot be left blank!")
        parser.add_argument('EMAIL',type=str,required=True,help="email cannot be left blank!")
        parser.add_argument('CONTACT',type=str,required=True,help="contact cannot be left blank!")
        parser.add_argument('ADDRESS',type=str,required=True,help="Address cannot be left blank!")
        parser.add_argument('PASS',type=str,required=True,help="password cannot be left blank!")
        data=parser.parse_args()
        try:
            x=query(f"""SELECT * FROM LEAVE_APP1.HOD_REGISTER WHERE HODID={data['HODID']}""",return_json=False)
            if len(x)>0: return {"message":"An emp with that hodid already exists."},400
        except:
            return {"message":"There was an error inserting into hod_register table."},500
        try:
            query(f"""INSERT INTO LEAVE_APP1.HOD_REGISTER VALUES({data['HODID']},
                                                        '{data['HODNAME']}',
                                                        {data['DEPTNO']},
                                                        '{data['DESG']}',
                                                        '{data['EMAIL']}',
                                                        '{data['CONTACT']}',
                                                        '{data['ADDRESS']}',
                                                        '{data['PASS']}')""")
        except:
            return {"message":"There was an error inserting into hod_register table."},500
        return {"message":"Successfully Inserted."},201
  

class User():
    def __init__(self,HODID,HODNAME,PASSWORD):
        self.HODID=HODID
        self.HODNAME=HODNAME
        self.PASSWORD=PASSWORD

    @classmethod
    def getUserByHname(cls,HODNAME):
        result=query(f"""SELECT HODID,HODNAME,PASS FROM HOD_REGISTER WHERE HODNAME='{HODNAME}'""",return_json=False)
        if len(result)>0: return User(result[0]['HODID'],result[0]['HODNAME'],result[0]['PASS'])
        return None

    @classmethod
    def getUserByhodno(cls,HODID):
        result=query(f"""SELECT HODID,HODNAME,PASS FROM HOD_REGISTER WHERE HODID='{HODID}'""",return_json=False)
        if len(result)>0: return User(result[0]['HODID'],result[0]['HODNAME'],result[0]['PASS'])
        return None
now = datetime.now()
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")

class HodLogin(Resource):
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('HODNAME',type=str,required=True,help="hod id cannot be left blank!")
        parser.add_argument('PASS',type=str,required=True,help="password cannot be left blank!")
        data=parser.parse_args()
        user=User.getUserByHname(data['HODNAME'])
        if user and safe_str_cmp(user.PASSWORD,data['PASS']):
            access_token=create_access_token(identity=user.HODID,expires_delta=False)
            hodname=data['HODNAME']
            return {' access_token ':access_token,'hodname':hodname},200
            
        return {"message":"Invalid Credentials!"}, 401

