from flask_restful import Resource,reqparse
from db import query
from flask_jwt_extended import jwt_required


class Leaveapprovalupdate(Resource):
    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('LEAVE_ID',type=int,required=True,help="leave id cannot be left blank!")
        parser.add_argument('LEAVE_STAT',type=int,required=True,help="leave stat cannot be left blank!")
        parser.add_argument('LEAVE_MSG',type=str,required=True,help="leave msg cannot be left blank!")
        data=parser.parse_args()
        try:
            query(f"""UPDATE LEAVE_APP1.LEAVES_APPROVAL
                                                        SET LEAVE_STAT={data['LEAVE_STAT']}, 
                                                            LEAVE_MSG='{data['LEAVE_MSG']}'
                                                            WHERE LEAVE_ID={data['LEAVE_ID']}""") 
        except:
            return {"message":"There was an error connecting to LEAVES_APPROVAL table."},500
        return {"message":"Successfully Inserted."},201