from flask_restful import Resource,reqparse
from werkzeug.security import safe_str_cmp
from flask_jwt_extended import create_access_token,jwt_required
from db import query
from datetime import datetime

class LeavesLeft(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT NOLEAVES FROM LEAVE_APP1.EMP_REGISTER WHERE EMPID={data['EMPID']}""")
        except:
            return {"message":"There was an error connecting to emp_register table."},500