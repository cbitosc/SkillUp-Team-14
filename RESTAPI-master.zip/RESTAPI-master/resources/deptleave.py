from flask_restful import Resource,reqparse
from db import query
from flask_jwt_extended import jwt_required


class Deptleave(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('DEPTNO',type=int,required=True,help="deptno cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.EMP_LEAVE_APPLICATION WHERE EMPID =ANY(SELECT EMPID FROM LEAVE_APP1.EMP_REGISTER WHERE DEPTNO={data['DEPTNO']}) and LEAVE_ID NOT IN (select LEAVE_ID FROM LEAVE_APP1.LEAVES_APPROVAL )""")
        except:
            return {"message":"There was an error connecting to dept table."},500