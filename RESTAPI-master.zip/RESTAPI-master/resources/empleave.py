from flask_restful import Resource,reqparse
from flask_jwt_extended import jwt_required
from db import query


class Empleave(Resource):
    @jwt_required
    def get(self):
        #parser=reqparse.RequestParser()
        #parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        #data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.EMP_LEAVE_APPLICATION WHERE LEAVE_ID NOT IN (select LEAVE_ID FROM LEAVE_APP1.LEAVES_APPROVAL )""")
        except:
            return {"message":"There was an error connecting to EMP_LEAVE_APPLICATION table."},500

    @jwt_required
    def post(self):
        parser=reqparse.RequestParser()
        parser.add_argument('EMPID',type=int,required=True,help="empid cannot be left blank!")
        parser.add_argument('LEAVETITLE',type=str,required=True,help="leave title cannot be left blank!")
        parser.add_argument('REASON',type=str,required=True,help="reason cannot be left blank!")
        parser.add_argument('STDATE',type=str,required=True,help="stdate cannot be left blank!")
        parser.add_argument('ENDDATE',type=str,required=True,help="enddate cannot be left blank!")
        parser.add_argument('NOOFDAYS',type=int,required=True,help="no od days cannot be left blank!")
        parser.add_argument('EMGLEAVE',type=int,required=True,help="emgleaves cannot be left blank!")
        
        data=parser.parse_args()
        try:
            x=query(f"""SELECT * FROM LEAVE_APP1.EMP_LEAVE_APPLICATION WHERE EMPID={data['EMPID']}""",return_json=False)
            if len(x)>0: return {"message":"An emp with that empid already exists."},400
        except:
            return {"message":"There was an error inserting into emp_register table."},500
        try:
            query(f"""INSERT INTO LEAVE_APP1.EMP_LEAVE_APPLICATION (EMPID, LEAVETITLE, REASON, STDATE, ENDDATE, NOOFDAYS, EMGLEAVE)
                                                    VALUES({data['EMPID']},
                                                        '{data['LEAVETITLE']}',
                                                        '{data['REASON']}',
                                                        '{data['STDATE']}',
                                                        '{data['ENDDATE']}',
                                                        {data['NOOFDAYS']},
                                                        {data['EMGLEAVE']})""")
        except:
            return {"message":"There was an error inserting into EMP_LEAVE_APPLICATION table."},500
        return {"message":"Successfully Inserted."},201
  