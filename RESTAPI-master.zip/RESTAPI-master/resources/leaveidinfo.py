from flask_restful import Resource,reqparse
from flask_jwt_extended import jwt_required
from db import query


class LeaveIdInfo(Resource):
    @jwt_required
    def get(self):
        parser=reqparse.RequestParser()
        parser.add_argument('LEAVE_ID',type=int,required=True,help="empid cannot be left blank!")
        data=parser.parse_args()
        try:
            return query(f"""SELECT * FROM LEAVE_APP1.EMP_LEAVE_APPLICATION WHERE LEAVE_ID={data['LEAVE_ID']} """)
        except:
            return {"message":"There was an error connecting to EMP_LEAVE_APPLICATION table."},500